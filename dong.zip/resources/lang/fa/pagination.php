<?php

return array(

    'previous' => '&laquo; قبلی',

    'next'     => 'بعدی &raquo;',

);
