@extends('user.main')
@section('content')
    {{dd($groups)}}
@endsection
