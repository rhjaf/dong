<?php $__env->startSection('content'); ?>
    <section>
        <div class="container-fluid">
            <div class="row mb-5">
                <div class="col-xl-10 col-lg-9 col-md-8 ml-auto">
                    <div class="row align-items-center">
                        <div class="col-12 mb-4 col-xl-12 mb-xl-0">
                            <h3 class="text-muted text-right mb-3">لیست گروه ها</h3>
                                <?php if(\Illuminate\Support\Facades\Session::has('group-update')): ?>
                                        <div class="ml-auto alert-success alert"><?php echo e(\Illuminate\Support\Facades\Session::get('group-update')); ?></div>
                                <?php elseif(\Illuminate\Support\Facades\Session::has('group-create')): ?>
                                    <div class="ml-auto alert-success alert"><?php echo e(\Illuminate\Support\Facades\Session::get('group-create')); ?></div>
                                <?php elseif(\Illuminate\Support\Facades\Session::has('group-delete')): ?>
                                        <div class="ml-auto alert-success alert"><?php echo e(\Illuminate\Support\Facades\Session::get('group-delete')); ?></div>
                                <?php endif; ?>
                                <?php echo $__env->yieldContent('content'); ?>
                            

                            </div>
                        <div class="col-sm-3">
                            <form action="<?php echo e(route('group.store')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('POST'); ?>
                                <div class="form-group">
                                    <label for="name">نام گروه</label>
                                    <input type="text" name="name" id="name" class="form-control" placeholder="نام گروه">
                                </div>
                                <div class="form-group">
                                    <label for="avatar">تصویر گروه</label>
                                    <input type="file" name="avatar" id="avatar" class="form-control-file">
                                </div>
                                <button type="submit" class="btn btn-block btn-success">ایجاد گروه</button>
                            </form>
                        </div>
                        <div class="col-sm-9">
                            <table class="table bg-light text-center table-striped">
                                <thead>
                                <tr class="text-muted">
                                    <th>#</th>
                                    <th>نام گروه</th>
                                    <th>لینک</th>
                                    <th>پروفایل</th>
                                    <th>ادمین</th>
                                    <th>حذف</th>
                                    <th>ویرایش</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                    $i = 0;
                                ?>
                                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <?php
                                            $i++;
                                        ?>
                                        <th><?php echo e($i); ?></th>
                                        <td><?php echo e($grp->name); ?></td>
                                        <td><?php echo e($grp->link); ?></td>
                                        <td><img width="30px" src="/uploads/avatars/<?php echo e($grp->avatar); ?>" class="rounded-circle img-thumbnail"></td>
                                        <td><?php echo e(\App\User::where('id',$grp->admin)->first()->name); ?></td>
                                        <?php if(\Illuminate\Support\Facades\Auth::user()->userIsAdmin($grp)): ?>
                                            <td class="text-center">
                                                <form method="POST" action="<?php echo e(route('group.destroy',$grp->id)); ?>">
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-block btn-light "><i class="text-danger fas fa-trash-alt"></i></button>
                                                </form>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('group.edit',$grp->id)); ?>"><i class="fas fa-edit text-primary"></i></a>
                                            </td>
                                        <?php else: ?>
                                            <td><?php echo e('تنها مدیر گروه این کار را میتواند بکند'); ?></td>
                                            <td><?php echo e('تنها مدیر گروه این کار را میتواند بکند'); ?></td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <!-- pagination -->

                            <nav>
                                <ul class="pagination justify-content-center">
                                    <?php echo e($groups->links()); ?>

                                </ul>
                            </nav>
                        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH M:\Courses\University\Analyzing and Design of System\dong\resources\views/user/groups.blade.php ENDPATH**/ ?>