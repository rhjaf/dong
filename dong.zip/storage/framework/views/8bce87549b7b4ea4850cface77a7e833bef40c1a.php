<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name')); ?></title>
    <link rel="title icon" type="image/png" href="<?php echo e(asset('images/icon.png')); ?>"/>
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Styles -->

    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-rtl.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/welcome/main.css')); ?>">
    <style>
        html{
            height: 100%;
        }
    </style>

    
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/all.js" integrity="sha384-xymdQtn1n3lH2wcu0qhcdaOpQwyoarkgLVxC/wZ5q7h9gHtxICrpcaSUfygqZGOe" crossorigin="anonymous"></script>
</head>
<body dir="rtl" style="margin:0;font-family: 'B Nazanin', 'Tahoma';font-size: 18px;background: linear-gradient(rgba(0, 0, 0, .7), rgba(0, 0, 0, .9)) no-repeat fixed" >
    <div id="app">
        <!-- navbar -->
        <nav class="navbar navbar-expand-sm fixed-top nav-menu" style="font-family: 'B Morvarid'">
            <a href="#" class="navbar-brand text-light text-uppercase" ><span class="h2 font-weight-bold">دونگی</span> <img class="figure-img mr-3" width="50" src="<?php echo e(asset('images/icon.png')); ?>"></a>
            <button class="navbar-toggler nav-button" type="button" data-toggle="collapse" data-target="#myNavbar">
                <div class="bg-light line1"></div>
                <div class="bg-light line2"></div>
                <div class="bg-light line3"></div>
            </button>
            <div class="collapse navbar-collapse justify-content-end text-uppercase font-weight-bold " id="myNavbar">
                <ul class="navbar-nav">
                    <li class="navbar-item">
                        <a href="<?php echo e(route('welcome')); ?>" class="nav-link m-2 menu-item <?php echo e('/'==request()->path()?'nav-active':''); ?>">خانه</a>
                    </li>
                    <li class="navbar-item">
                        <a href="<?php echo e(route('login')); ?>" class="nav-link m-2 menu-item <?php echo e('login'==request()->path()?'nav-active':''); ?>">ورود</a>
                    </li>
                    <li class="navbar-item">
                        <a href="<?php echo e(route('register')); ?>" class="nav-link m-2 menu-item <?php echo e('register'==request()->path()?'nav-active':''); ?>">ثبت نام</a>
                    </li>
                    <li class="navbar-item">
                        <a href="<?php echo e(route('about')); ?>" class="nav-link m-2 menu-item <?php echo e('about'==request()->path()?'nav-active':''); ?>">درباره ما</a>
                    </li>
                </ul>
            </div>

        </nav>
        <!-- end of navbar -->

        <main class="py-4 " style="margin-top: 100px">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    <footer class="bg-dark px-5 " style="display: <?php echo e('about'==request()->path()?'block':'none'); ?>">
        <div class="container-fluid">
            <div class="row">
                <div class="col text-center text-light border-top pt-3">
                    &copy; Copyright 2020 Made With
                    <i class="fab fa-laravel text-danger"></i>
                    by <a class="text-success" href="https://rhjaf.github.io">RHJAR</a>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>
<?php /**PATH M:\Courses\University\Analyzing and Design of System\dong\resources\views/layouts/app.blade.php ENDPATH**/ ?>