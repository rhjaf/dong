<?php $__env->startSection('content'); ?>
    <section class="container-fluid">

        <div class="row">
            <div class="col-xl-10 col-md-8 col-lg-9 ml-auto">
                <h1> گروه :  <?php echo e($group->name); ?></h1>
                <div class="row">
                    <div class="col-sm-3">
                        <form action="<?php echo e(route('group.update',$group)); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="mb-4">
                                <img width="150px" height="" class="img-profile rounded-circle " src="/uploads/avatars/<?php echo e($group->avatar); ?>">
                            </div>
                            <div class="form-group">
                                <input type="file" name="avatar">
                            </div>


                            <div class="form-group">
                                <label for="name">نام</label>
                                <input type="text" name="name" id="name" class="form-control <?php echo e($errors->has('name')?'is-invalid':''); ?>" value="<?php echo e($group->name); ?>">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <button type="submit" class="btn btn-primary">بروزرسانی</button>

                        </form>
                    </div>
                    <div class="col-sm-9">
                        <?php if(\Illuminate\Support\Facades\Session::has('remover-user-from-group')): ?>
                            <div class="ml-auto alert-success alert"><?php echo e(\Illuminate\Support\Facades\Session::get('remover-user-from-group')); ?></div>
                        <?php elseif(\Illuminate\Support\Facades\Session::has('add-user-to-group')): ?>
                            <div class="ml-auto alert-success alert"><?php echo e(\Illuminate\Support\Facades\Session::get('add-user-to-group')); ?></div>
                        <?php endif; ?>
                        <table class="table bg-light text-center table-striped">
                            <thead>
                            <tr class="text-muted">
                                <th>#</th>
                                <th>نام</th>
                                <th>پروفایل</th>
                                <th> حذف از گروه</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
                                $i = 0;
                            ?>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($user->id != \Illuminate\Support\Facades\Auth::user()->id): ?>
                                    <tr>
                                        <?php
                                            $i++;
                                        ?>
                                        <th><?php echo e($i); ?></th>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><img width="30px" src="/uploads/avatars/<?php echo e($user->avatar); ?>" class="rounded-circle img-thumbnail"></td>
                                        <td class="text-center">
                                            <form method="POST" action="<?php echo e(route('group.removeuser',[$group->id,$user->id])); ?>">
                                                <?php echo method_field('PUT'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" onmouseleave="this.style.color=''" onmouseover="this.style.color='red'" class="btn btn-block transparent "><i class="fas fa-trash-alt"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                            <nav>
                                <ul class="pagination justify-content-center">
                                    <?php echo e($users->links()); ?>

                                </ul>
                            </nav>
                    </div>
                </div>
                <div class="row" style="margin-top: 8px">
                    <div class="col-sm-3">اضافه کردن عضو
                        <form method="POST" action="<?php echo e(route('group.adduser',$group->id)); ?>">
                        <div id="custom-search-input">
                                <?php echo method_field('PUT'); ?>
                                <?php echo csrf_field(); ?>
                            <div class="input-group ">
                                <input id="search" name="name" type="text" class="form-control" placeholder="نام کاربر" autocomplete="off"/>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success " style="margin-top: 8px">اضافه کردن</button>
                        </form>

                    </div>
                </div>

            </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js"></script>
    <script type="text/javascript">
        var route = "<?php echo e(url('autocomplete')); ?>";
        $('#search').typeahead({
            source:  function (term, process) {
                return $.get(route, { term: term }, function (data) {
                    return process(data);
                });
            }
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('user.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH M:\Courses\University\Analyzing and Design of System\dong\resources\views/user/group.blade.php ENDPATH**/ ?>