<!doctype html>
<html lang="fa">
<head>
    
    <meta charset="utf-8" data-html="true">
    <meta name="viewport"  content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="title icon" type="image/png" href="<?php echo e(asset('images/icon.png')); ?>"/>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/all.js" integrity="sha384-xymdQtn1n3lH2wcu0qhcdaOpQwyoarkgLVxC/wZ5q7h9gHtxICrpcaSUfygqZGOe" crossorigin="anonymous"></script>

    
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-rtl.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">

    <?php echo $__env->yieldContent('style'); ?>

    <title>پنل کاربری</title>



</head>
<body >
<!--navbar-->
<nav class="navbar navbar-expand-md navbar-light flex-column-reverse" >
    <button class="navbar-toggler ml-auto mb-2 bg-light" type="button" data-toggle="collapse" data-target="#myNavBar">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse " id="myNavBar">
        <div class="container-fluid ">
            <div class="row " >

                <!--sidebar-->
                <!--sidebar is not bootstrap class-->
                <div class="col-xl-2 col-lg-3 col-md-4 sidebar fixed-top ">
                    <!--bottom border is not a CSS class-->
                    <a href="#" class="navbar-brand text-white d-block mx-auto text-center py-3 mb-4 bottom-border">
                        <img class="figure-img" width="50" src="<?php echo e(asset('images/icon.png')); ?>">
                        <span style = 'font-family: B Morvarid'>دونگی</span>
                    </a>
                    <div class="bottom-border pb-3" >
                        <img src="/uploads/avatars/<?php echo e(auth()->user()->avatar); ?>" width="50" class="rounded-circle ml-3">
                        <a href="#" class="text-white"><?php echo e(auth()->user()->name); ?></a>
                    </div>
                    <ul class="navbar-nav flex-column mt-4">
                        <li class="nav-item ">
                            <a href="<?php echo e(route('user')); ?>" class="nav-link text-white p-3 mb-2 sidebar-link <?php echo e('user'==request()->path()?'current':''); ?>"><i class="fas fa-home text-light fa-lg mr-3"></i> خانه</a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('user.profile.show',auth()->user())); ?>" class="nav-link text-white p-3 mb-2 sidebar-link <?php echo e('user/'.auth()->user()->id.'/profile'==request()->path()?'current':''); ?>"><i class="fas fa-user text-light fa-lg mr-3"></i> پروفایل</a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('user.groups',auth()->user())); ?>" class="nav-link text-white p-3 mb-2 sidebar-link <?php echo e('user/'.auth()->user()->id.'/groups'==request()->path()?'current':''); ?>"><i class="fas fa-users text-light fa-lg mr-3"></i> گروه ها</a>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="nav-link text-white p-3 mb-2 sidebar-link <?php echo e('inbox'==request()->path()?'current':''); ?>"><i class="fas fa-envelope text-light fa-lg mr-3"></i> پیامها</a>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="nav-link text-white p-3 mb-2 sidebar-link <?php echo e('cost'==request()->path()?'current':''); ?>"><i class="fas fa-shopping-cart text-light fa-lg mr-3"></i> هزینه ها</a>
                        </li>

                    </ul>
                </div>
                <!--end of sidebar-->

                <!--top nav-->
                <!--top-navbar is not bootstrap class-->
                <div class="col-xl-2 col-lg-2 col-md-2 ml-auto bg-dark fixed-top py-2 top-navbar " style="border-radius: 0 7% 7% 0">
                            <ul class="navbar-nav">
                                <!-- icon-parent and icon-bullet are not bootstrap classes-->
                                <li class="nav-item icon-parent"><a class="nav-link icon-bullet" href="#"><i class="fas fa-comments text-muted fa-lg"></i></a></li>
                                <li class="nav-item icon-parent"><a class="nav-link icon-bullet" href="#"><i class="fas fa-bell text-muted fa-lg"></i></a></li>
                                <li class="nav-item ml-md-auto"><a class="nav-link" href="#" data-toggle="modal" data-target="#sign-out"><i class="fas fa-sign-out-alt text-danger fa-lg"></i></a></li>
                            </ul>
                        </div>

                </div>
                <!--end of top nav-->
            </div>
        </div>
    </div>
</nav>
<!--end of navbar-->
<!--modal-->
<div class="modal fade" id="sign-out">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"> خروج از حساب کاربری</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                آیا مطمئن به خروج هستید؟
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success" data-dismiss="modal">ماندن</button>
                <form method="POST" action="/logout">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-danger" >خروج</button>

                </form>
            </div>
        </div>
    </div>
</div>
<!--end of modal-->
<section class="container-fluid">
        <?php if(\Illuminate\Support\Facades\Session::has('group-created')): ?>
            <div class="row">
                <div class="col-xl-10 col-md-8 col-lg-9 ml-auto alert-success alert"><?php echo e(\Illuminate\Support\Facades\Session::get('group-created')); ?></div>
            </div>
        <?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
</section>









<!-- floating button -->

<a id="fab" style="display: inline-block;position: fixed;left:20px;bottom:20px;color:#eee;box-shadow:0px 5px 5px  gray;font-weight:bold;font-size:40px;width: 40px;height: 40px;border-radius: 50%;background:linear-gradient(to bottom,rgb(266,3,3),rgb(255,65,65));cursor: pointer;line-height: 40px" align="center"  data-toggle="modal" data-target="#newGroupModal">+</a>
<!-- end of floating button -->
<!-- New Group Modal -->
<!-- Modal -->
<div class="modal fade" id="newGroupModal" tabindex="-1" role="dialog" aria-labelledby="newGroupModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">گروه جدید</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                    <form action="<?php echo e(route('group.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <div class="form-group">
                            <label for="name">نام گروه</label>
                            <input type="text" name="name" id="name" class="form-control" placeholder="نام گروه">
                        </div>
                        <div class="form-group">
                            <label for="avatar">تصویر گروه</label>
                            <input type="file" name="avatar" id="avatar" class="form-control-file">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">انصراف</button>
                            <button type="submit" class="btn btn-success">ایجاد گروه</button>
                        </div>
                    </form>
            </div>
        </div>
    </div>
</div>
<!-- end of New Group Modal -->


<!-- footer -->
<footer>
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-10 col-lg-9 col-md-8 ml-auto">
                <div class="row border-top pt-3">

                    <div class="col-lg-12 text-center">
                        <p>
                            &copy; Copyright 2020 Made With
                            <i class="fab fa-laravel text-danger"></i>
                            by <a class="text-success" href="https://rhjaf.github.io">RHJAR</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<!-- Scripts -->
<script src="<?php echo e(asset('js/bootstrap.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>

<!-- end of footer -->
<script src="<?php echo e(asset('js/script.js')); ?>"></script>

<!-- AJAX for creating group -->
<?php echo $__env->yieldContent('script'); ?>


</body>
</html>
<?php /**PATH M:\Courses\University\Analyzing and Design of System\dong\resources\views/user/main.blade.php ENDPATH**/ ?>